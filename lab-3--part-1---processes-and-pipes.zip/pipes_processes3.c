#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>

int main(int argc, char **argv)
{
    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s <search_argument>\n", argv[0]);
        return 1;
    }

    int pipe1[2]; // P1 to P2 pipe
    int pipe2[2]; // P2 to P3 pipe
    int pid1, pid2;

    char *cat_args[] = {"cat", "scores", NULL};
    char *grep_args[] = {"grep", argv[1], NULL};
    char *sort_args[] = {"sort", NULL};

    // Create the first pipe (P1 to P2)
    if (pipe(pipe1) == -1)
    {
        perror("Pipe 1 failed");
        return 1;
    }

    // Create the second pipe (P2 to P3)
    if (pipe(pipe2) == -1)
    {
        perror("Pipe 2 failed");
        return 1;
    }

    pid1 = fork();

    if (pid1 < 0)
    {
        perror("Fork P1 failed");
        return 1;
    }
    else if (pid1 == 0) // P1 (Child)
    {
        // P1: Replace standard output with the write end of the first pipe
        dup2(pipe1[1], 1);
        close(pipe1[0]);
        close(pipe1[1]);
        close(pipe2[0]);
        close(pipe2[1]);

        // Execute "cat scores"
        execvp("cat", cat_args);
    }
    else // P1 (Parent)
    {
        pid2 = fork();
        if (pid2 < 0)
        {
            perror("Fork P2 failed");
            return 1;
        }
        else if (pid2 == 0) // P2 (Child)
        {
            // P2: Replace standard input with the read end of the first pipe
            dup2(pipe1[0], 0);
            // Replace standard output with the write end of the second pipe
            dup2(pipe2[1], 1);
            close(pipe1[0]);
            close(pipe1[1]);
            close(pipe2[0]);
            close(pipe2[1]);

            // Execute "grep <search_argument>"
            execvp("grep", grep_args);
        }
        else // P1 (Parent)
        {
            close(pipe1[0]);
            close(pipe1[1]);

            // P1: Wait for P2 to finish
            wait(NULL);
        }
    }

    // P1 (Parent)
    int pid3 = fork();

    if (pid3 < 0)
    {
        perror("Fork P3 failed");
        return 1;
    }
    else if (pid3 == 0) // P3 (Child)
    {
        // P3: Replace standard input with the read end of the second pipe
        dup2(pipe2[0], 0);
        close(pipe2[0]);
        close(pipe2[1]);

        // Execute "sort"
        execvp("sort", sort_args);
    }
    else // P1 (Parent)
    {
        close(pipe2[0]);
        close(pipe2[1]);

        // P1: Wait for P3 to finish
        wait(NULL);
    }

    return 0;
}
