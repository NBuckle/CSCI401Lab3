#include  <stdio.h>
#include  <stdlib.h>
#include  <sys/types.h>
#include  <sys/ipc.h>
#include  <sys/shm.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>

//void  ClientProcess(int []);
void  ChildProcess();
void ParentProcess();
int *BankAccount;
int *Turn;

int  main(int  argc, char *argv[]){
  //int  ShmID;
  int  *ShmPTR;
  pid_t  pid;
//  int status;
  int BankAccountShmID, TurnShmID;

  BankAccountShmID = shmget(IPC_PRIVATE, sizeof(int), IPC_CREAT | 0666);
  if (BankAccountShmID < 0) {
      perror("*** shmget error (BankAccount) ***");
      exit(1);
  }

  // Create shared memory for Turn
  TurnShmID = shmget(IPC_PRIVATE, sizeof(int), IPC_CREAT | 0666);
  if (TurnShmID < 0) {
      perror("*** shmget error (Turn) ***");
      exit(1);
  }

  // Attach shared memory segments
  BankAccount = (int *)shmat(BankAccountShmID, NULL, 0);
  if (*BankAccount == -1) {
      perror("*** shmat error (BankAccount) ***");
      exit(1);
  }

  Turn = (int *)shmat(TurnShmID, NULL, 0);
  if (*Turn == -1) {
      perror("*** shmat error (Turn) ***");
      exit(1);
  }
  // Initialize shared variables
  *BankAccount = 0;
  *Turn = 0;

  srand(time(NULL));
  printf("Server is about to fork a child process...\n");
  pid = fork();
  if (pid < 0) {
      printf("*** fork error (server) ***\n");
      exit(1);
  }
  else if (pid == 0){
    ChildProcess();
  }
  else {
    ParentProcess();
    wait(NULL);
    //ClientProcess(ShmPTR);
    //exit(0);
  }
    // Detach and remove shared memory
  shmdt((void *)BankAccount);
  shmdt((void *)Turn);

  shmctl(BankAccountShmID, IPC_RMID, NULL);
  shmctl(TurnShmID, IPC_RMID, NULL);
  exit(0);
}

void ParentProcess(){
  int sleep_duration, account, balance;
  for (int i = 0; i < 25; i++) {
    // Sleep some random amount of time between 0 - 5 seconds
    sleep_duration = rand() % 6;
    sleep(sleep_duration);

    // After waking up, copy the value in BankAccount to a local variable account
    account = *BankAccount;

    // Loop while Turn != 0 (do-nothing loop)
    while (*Turn != 0);
    if (account <= 100) {
      balance = rand() % 101;
      if (balance % 2 == 0) {
            *BankAccount += balance;
            printf("Dear old Dad: Deposits $%d / Balance = $%d\n", balance, *BankAccount);
        } else {
            printf("Dear old Dad: Doesn't have any money to give\n");
        }
    } else {
        printf("Dear old Dad: Thinks Student has enough Cash ($%d)\n", account);
    }

    // Set Turn to 1 to indicate the child's turn
    *Turn = 1;
  }
}

void ChildProcess(){
  int sleep_duration, account, balance;
  for (int i = 0; i < 25; i++) {
    sleep_duration = rand() % 6;
    sleep(sleep_duration);
    // After waking up, copy the value in BankAccount to a local variable account
    account = *BankAccount;
    while (*Turn != 1);
    balance = rand() % 51;
    printf("Poor Student needs $%d\n", balance);
    if (balance <= account){
      account -= balance;
      printf("Poor Student: Withdraws $%d / Balance = $%d\n", balance, account);
    }
    else{
      printf("Poor Student: Not Enough Cash ($%d)\n", account );
    }
    *BankAccount = account;
    *Turn = 0;
  }
}
